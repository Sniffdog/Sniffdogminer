Z-ENEMY VER 1.08 ( PUBLIC )

For Windows (Cuda 9.0)
zealot/enemy-1.08 (z-enemy)  From: Dk & Enemy
-Kernels speed improvements for GTX 1080 Ti (+10% total)
-Added x16s ( up to 10-20%), fast Bitcore(BTX), fast Phi1612(LUX)
-minor miner fixes ...

This release is reported to be more stable when it comes to higher PL or overclocking, feel free to experiment with it.
______________________________________
RECOMMENDED SETTING:
First start:
1) for better stability and speed, update your drivers on http://www.nvidia.com/Download/index.aspx
ver, 390++++
2) PL 80% or more, depends on your PSU
3) Core :( +0, +50 or more )
4) Mem : ( +0 up to + 500 (carefull!!))
5) Recommended intensity is 20, set 21 only if you know what you do ( 16GB RAM or/and good SWAP file on SSD)
6) Yiimp pools rec manual diff, like : ( -p d=16 ) - for  small farms or  (-p d=48 )- for good farms like 6-8 1080ti

OverClock ( on your own risk !) slowly, after stable work ( core,mem and PL) . 
For best perfomace PowerLimit 90% or higher , Core up  100+ , Mem up to 200++ ( best for Ti Cards) , intensity for 1080Ti - up to 21. 

P.S.  Please upload only my links or links confirmed by me, for security reasons !
