Z-ENEMY VER 1.09a ( PUBLIC )

For Windows (Cuda 9.1)
zealot/enemy-1.09a (z-enemy)  From: Dk & Enemy

- Kernels speed improvements 1.08 vs 1.09a, for all 9x0 and 10x0 GTX:
 x16r +5-8%, x16s +5-10%, bitcore +5-8%, xevan +5-20% ( vs basic public), phi + 2-3%, x17 (basic), vit (new algo).

- Support new algos : Xevan (-a xevan) and Vitality (-a vit), reccomended intensity for Xevan 19-20, for Vitality 19-21

- "Search mode" is enabled on 1.09a! This means that if you use a low diff you may see extra shares come through on your miner. You may see something like "2 shares" or "3 shares", up to 10+. This is a BONUS!.If you can find more than one share on your scan range you�ll find them all.If you have a bigger farm and use a higher diff you may also see the double or triple shares ,but it will be more rare. I still advise larger farms to continue to use higher diff. 

- Revised dev-fee mechanism. Now the miner does not break off connection with a pool and does not drop work of video cards. Everything works without switch-offs.

- Now supporting failover pool! It is now possible to add additional pools incase your main pool loses stratum connection. Here is an example for your .bat file: 
z-enemy -a x16r -o stratum+tcp://ravenminer.com:6666 -u RFQXKVKpHMwyJ86YqQUJSZK1S8m8oRbC5h -p d=16 -o stratum+tcp://krawww-miner.eu:3636 -u RFQXKVKpHMwyJ86YqQUJSZK1S8m8oRbC5h -p d=3

- Duplicate output into log file (-l, --log=logfile.txt )

- Better error reporting. Now you see device number with its name if you encounter any cuda errors.

- Pool latency. When submitting shares now you see pool's response time in milliseconds.


This release is reported to be more stable when it comes to higher PL or overclocking, feel free to experiment with it.
______________________________________
First time or troubleshooting x16:
-���First time users - ver. 1.08 works on Cuda 9.1 and it is recommended to make sure you've updated your NVIDIA drivers. You can find drivers here: http://www.nvidia.com/Download/index.aspx ver., 390+++
-���Next important thing is intensity. We recommend intensity -19 at first, however if your PC has 8GB or more, fast SSD, and big swap file on it you may use -20/21.
-���X16r algo is very wild and eratic. �*Very important* �Make sure to have enough power reserve on PSU. Please be sure you have a minimum 20% headroom on your PSU or set your PL on 70-80% usage.
-���Using +core and +mem is useful but, use no OC at first until you verify stability. 


Performance and fine tuning x16: 
-���This release z-enemy 1.08 is reported to be more stable when it using higher PL (90-110%) and +core and +memory overclocking, feel free to experiment with it.
-���Updating drivers can provide more gains
-���Recommended intensity is 20, set 21 only if you know what you are doing. ( 16GB RAM or/and good SWAP file on SSD) Use caution
-���Recommended memory � 0 or +
-���Recommended core +50+150 ( 1800-1900MHz 1080 Ti)
-���Overclock slowly and allow plenty of time to verify stability (12-24hrs) before making anymore adjustments. x16r is a very chaotic algorithm so just because it works for 1 hr doesn't mean you can't crash over longer time. Sometimes hash order can lead to 2000+mhz and crash system. Keep in mind � overclocking is always at your own risk!
-���Yiimp pools recommend �manual diff (-p d=16) - for �small farms or �(-p d=48 ) - for good farms like 5-6 1080 Ti � If you need to name your rigs as well as set diff you may try -p rigname,d=16
