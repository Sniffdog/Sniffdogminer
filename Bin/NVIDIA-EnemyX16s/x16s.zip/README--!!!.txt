Miner is free and friendly for Pigeon community , no dev fee inc !!!


If you find my work useful, feel free to donate on my (RVN) or  run *.cmd , 
for motivation to improve the miner and make the version under Linux :)


My Pigeon: PLiVo5yFKY6PR5CiUB8Xz2AgXYsSMNnMtv

Thanks.


RECOMMENDED SETTING:
First start:
1) for better stability and speed, update your drivers on http://www.nvidia.com/Download/index.aspx
ver, 390++++
2) PL 70-80% ( depend on PSU )
3) Core :( some + or stock )
4) Mem : (minus -502, 300 or stock)
5) Intensity default : ( -i 19  )
6) Yiimp pools rec manual diff, like : ( -p d=16 )

OC slowly, after stable work ( core,mem and PL) . High intensity not recommended !!! ( -i 20, 21 , but possible).

P.S. The enemy of your enemy is a friend :)
Please upload only my links or links confirmed by me, for security reasons !!!